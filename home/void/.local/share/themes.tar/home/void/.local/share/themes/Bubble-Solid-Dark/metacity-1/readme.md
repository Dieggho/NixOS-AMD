# Credits
Metacity themes base on [Arc-Theme](https://github.com/horst3180/arc-theme) </br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Extract archive files in directory /.themes, /.local/share/themes or /usr/share/themes (as root)</b>
Have been test on : Linux Mint 20 (Ulyana) Cinnamon Edition</br>

## Change themes
Cinnamon: Menu > Settings > Themes > Windows Border </br>
